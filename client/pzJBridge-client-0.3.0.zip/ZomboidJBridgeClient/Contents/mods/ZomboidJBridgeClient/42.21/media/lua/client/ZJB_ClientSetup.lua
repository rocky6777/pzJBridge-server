require "ISUI/ISButton"
require "ISUI/ISCollapsableWindow"
require "ISUI/ISRichTextPanel"
require "OptionScreens/MainScreen"

ZJBClientSetup = ZJBClientSetup or {}
ZJBClientSetup.version = "0.3.0"
ZJBClientSetup.name = "pzJBridge(" .. ZJBClientSetup.version .. ")"
local SetupWindow = ISCollapsableWindow:derive("ZJBClientSetupWindow")

function SetupWindow:createChildren()
    ISCollapsableWindow.createChildren(self)
    local top = self:titleBarHeight() + 12
    self.instructions = ISRichTextPanel:new(12, top, self.width - 24, self.height - top - 12)
    self.instructions:initialise()
    self.instructions:instantiate()
    self.instructions.background = false
    self.instructions:addScrollBars()
    self.instructions.text = "<H1> " .. ZJBClientSetup.name .. " <LINE> " ..
        "<TEXT> Agent 0.3.0 | Game profile 42.21 <LINE> <LINE> " ..
        "<H2> One-time setup <LINE> " ..
        "<TEXT> Enabling this Workshop mod does not start the Java agent. " ..
        "Close Zomboid, open this mod's common folder, and follow SETUP.md to run Install-ClientAgent.ps1. " ..
        "The installer saves a launcher backup and configures the included agent JAR. <LINE> <LINE> " ..
        "<H2> Joining a bridge server <LINE> " ..
        "<TEXT> Restart Zomboid using its normal launcher after installing. " ..
        "The Java agent supplies its compatibility hello during login. " ..
        "A bridge server can reject a client without the matching agent or required Java extensions. " ..
        "An Access denied message can mean the required agent is missing. <LINE> <LINE> " ..
        "<H2> Status and troubleshooting <LINE> " ..
        "<TEXT> This help window does not verify whether the agent is running. " ..
        "Check the startup log for [ZomboidJBridge] Listener installed; side=CLIENT. " ..
        "If a Steam update replaces the launcher JSON, close the game and rerun the installer. <LINE> <LINE> " ..
        "<TEXT> Developer MCP inspection is optional and disabled by the installer unless requested. " ..
        "To use Codex, enable MCP AND merge codex-mcp.example.toml into your Codex settings. " ..
        "See SETUP.md for paths and restart instructions. <LINE> <LINE> " ..
        "<TEXT> Server installer: github.com/rocky6777/pzJBridge-server <LINE> <LINE> " ..
        "This tool checks compatibility; it is not an anti-cheat system."
    self:addChild(self.instructions)
    self.instructions:paginate()
end

function ZJBClientSetup.show()
    if ZJBClientSetup.window then
        ZJBClientSetup.window:setVisible(true)
        ZJBClientSetup.window:addToUIManager()
        ZJBClientSetup.window:bringToTop()
        return
    end
    local width = math.min(620, getCore():getScreenWidth() - 40)
    local height = math.min(470, getCore():getScreenHeight() - 40)
    local window = SetupWindow:new((getCore():getScreenWidth() - width) / 2,
        (getCore():getScreenHeight() - height) / 2, width, height)
    window.title = ZJBClientSetup.name .. " Setup"
    window.resizable = false
    window:initialise()
    window:instantiate()
    window:addToUIManager()
    ZJBClientSetup.window = window
end

local function addSetupButton()
    local main = MainScreen and MainScreen.instance
    if not main then return end
    -- Change only the menu text, preserving the engine's version for networking and saves.
    if main.version and not string.find(main.version, ZJBClientSetup.name, 1, true) then
        main.version = main.version .. " " .. ZJBClientSetup.name
    end
    if main.versionBtn and main.version then
        local key = getSteamModeActive() and "UI_mainscreen_version_steam" or "UI_mainscreen_version"
        local title = getText(key, main.version)
        local width = getTextManager():MeasureStringX(UIFont.Small, title) + 10
        main.versionBtn:setTitle(title)
        main.versionBtn:setWidth(width)
        main.versionBtn:setX((main.width - width) / 2)
    end
    if main.zjbSetupButton then return end
    local button = ISButton:new(20, 20, 200, 28, "Java Agent Setup", nil, ZJBClientSetup.show)
    button:initialise()
    button:instantiate()
    main:addChild(button)
    main.zjbSetupButton = button
end

Events.OnMainMenuEnter.Add(addSetupButton)
