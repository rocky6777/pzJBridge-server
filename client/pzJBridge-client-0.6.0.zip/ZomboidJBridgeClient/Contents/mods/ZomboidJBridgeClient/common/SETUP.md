# pzJBridge(0.6.0)

Client Options → **Bridge** now contains bridge and extension preferences. Sandbox creation → **Bridge** contains saved world settings; multiplayer uses server settings. Apply/Accept saves local changes. Debug is off by default; enable it globally or for an individual extension for detailed logs and diagnostics. Updating the Workshop companion alone does not replace your installed startup agent; run the installer with the game closed.

This Workshop item contains the Java agent and a Lua setup-help window for **Project Zomboid 42.21**. Enabling the Workshop mod alone does not start the agent: a Java agent must be specified before the JVM starts.

## Windows installation

1. Subscribe/enable the companion mod, then quit Project Zomboid normally.
2. Find the downloaded item's `mods/ZomboidJBridgeClient/common` folder. For a local authoring copy, it is `Contents/mods/ZomboidJBridgeClient/common`.
3. Right-click `Install-ClientAgent.ps1` and choose **Run with PowerShell**, then enter the game directory when asked. Alternatively, open PowerShell in that folder and run the installer with your client game directory:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-ClientAgent.ps1 -GameDirectory 'D:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid'
```

The execution-policy override applies only to this PowerShell process; it does not change your saved system policy. Review the installer before running it.

The installer verifies the supported game-class fingerprint and bundled agent checksum, backs up `ProjectZomboid64.json`, copies the agent to `%LOCALAPPDATA%\ZomboidJBridge`, and adds a client-mode startup option. Existing JVM options and other Java agents are preserved. The Workshop path is not used as the runtime JAR location, so unsubscribing or a Workshop folder change does not leave a broken path.

4. Start Zomboid using the normal launcher that reads `ProjectZomboid64.json`. Enable the companion mod to see the main-menu **Java Agent Setup** button. Batch-file launchers may construct their own Java command and need the same startup option separately.
5. Check the startup log for `[ZomboidJBridge] Listener installed; side=CLIENT`. The setup window itself does not detect or attest agent installation.

The matching server agent requires protocol/agent versions and any server-required Java extensions to match. The tested server rejects a client without the agent before admission. Join rejection includes the reason, required/mismatched Java mods, manual installer steps and a direct client ZIP URL, including on clients without the agent. The stock client surrounds this explanation with its translated missing-mod text.

With this companion enabled, the menu version line includes `pzJBridge(0.6.0)` alongside pzBullet. This identifies the companion version; check the startup log to confirm the Java agent is running.

## Java extensions from Workshop

Starting with bridge 0.3.0, install the bridge once, subscribe to compatible Java extension mods, wait for Steam to finish downloading, then restart Zomboid. The bridge discovers their declared JARs automatically; copying each extension JAR manually is no longer required. Mods must include `pzjbridge.properties` with `bridgeVersion=0.6.0` and a list of extension JARs.

Discovery reads Steam's installed-item index before the game/Steam initialization and ignores unrelated JARs and authoring drafts. It loads declarations from the item's `42.21/` folder, falling back to `common/`. Wait for Steam to finish updates or unsubscriptions before restarting. Java loading does not follow the enabled Lua-mod list: disabling a Lua companion does not unload its extension. Unsubscribe and let Steam remove the installed entry, then restart, or rerun installation with `-DisableWorkshop` to disable all automatic loading. Custom Steam layouts may use `-WorkshopDirectory 'D:\path\workshop\content\108600'`.

Both client and server must upgrade their startup agent to 0.6.0; changing the Workshop Lua companion alone does not update the agent copied to the stable installation folder. Missing or incompatible declared JARs fail startup with a useful error instead of silently omitting required hooks.

After Steam updates, rerun the installer if the launcher JSON was replaced. An unsupported game profile is rejected until the agent's hooks have been reviewed for that build.

## Uninstall

Close the game, then run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-ClientAgent.ps1 -GameDirectory 'D:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid' -Uninstall
```

Unsubscribing by itself does not remove a saved Java startup option. The uninstall command removes only this bridge's option and leaves its stable JAR and launcher backups available; delete those files manually if you no longer need them.

## Optional developer MCP

MCP is optional for playing. **For Codex inspection, you must enable MCP in the agent AND apply the Codex MCP settings.** Installing the agent alone does not configure Codex.

1. Install Python 3.9+ and JDK 25, including `java` and `javap`.
2. Copy this folder's bundled `tools` directory (including `mcp_bridge.py`, `cfr-0.152.jar` and its MIT license) to a stable location such as `C:\PZBridge\client\tools`.
3. With Zomboid closed, run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-ClientAgent.ps1 -GameDirectory 'D:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid' -EnableMcp -McpFile 'C:\PZBridge\connections\client.json'
```

4. Merge the following table, also supplied in `codex-mcp.example.toml`, into `%USERPROFILE%\.codex\config.toml`. Replace every example path with the paths on your machine. Keep existing settings and other MCP entries; update rather than duplicate an existing `zomboid_client` table. A trusted project's `.codex/config.toml` can also scope this connection.

```toml
[mcp_servers.zomboid_client]
command = 'C:\Python314\python.exe'
args = [
  'C:\PZBridge\client\tools\mcp_bridge.py',
  '--connection-file', 'C:\PZBridge\connections\client.json',
  '--java', 'C:\Program Files\Zulu\zulu-25\bin\java.exe',
  '--javap', 'C:\Program Files\Zulu\zulu-25\bin\javap.exe',
  '--cfr', 'C:\PZBridge\client\tools\cfr-0.152.jar',
]
tool_timeout_sec = 45
```

5. Restart Codex and start Zomboid using its configured launcher. Ask Codex to call `zomboid_client.agent_status`, then `read_game_class` for `zombie.network.packets.connection.LoginPacket` with `format=java`. The game must be running for inspection calls to work. The reconstructed Java is not exact original source.

This configuration follows [official OpenAI MCP instructions](https://learn.chatgpt.com/docs/extend/mcp). MCP is disabled by default and binds only to loopback when enabled. The connection file contains a private token: do not share or publish it. Agent setup does not install Python/JDK or modify Codex configuration automatically.

## Dedicated-server installer

Server owners can download the matching built agent, installer, launcher and MCP tools from [pzJBridge-server on GitHub](https://github.com/rocky6777/pzJBridge-server). The repository also includes the built client ZIP. Choose the downloads from its README and follow the installation instructions. The dedicated server must use its supplied launcher because stock server batch files ignore the JSON startup settings.

## Other platforms

Copy `java/zomboidjbridge-0.6.0.jar` to a stable local location and add the following JVM startup option before the game's main class, replacing both paths:

```text
-javaagent:/stable/path/zomboidjbridge-0.6.0.jar=side=client;gameJar=/path/to/ProjectZomboid/projectzomboid.jar
```

The PowerShell installer is Windows-only. The bundled agent requires Java 25 and the verified 42.21 login-class profile. It does not dynamically attach, provide gameplay features, or act as an anti-cheat system.
