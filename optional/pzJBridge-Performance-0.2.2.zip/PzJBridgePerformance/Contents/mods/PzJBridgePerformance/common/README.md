# pzJBridge Performance Boost 0.2.2

One `pzjbridge-performance-0.2.2.jar` works on B42.21 single-player clients, multiplayer clients and dedicated servers. Requires bridge 0.7.3. Java/game/Byte Buddy classes are compile-only; they are not included in the mod JAR.

Enable **PzJBridgePerformance** in the native mod selection. Disable it to restore the original transformed methods and remove its cooperative budgets. The bridge handshake does not require a matching client Java extension for this optimizer. Zomboid's native Workshop/mod requirements still apply to the companion mod files. Bridge and required gameplay extensions still follow their normal admission checks.

Options > Bridge > Performance Boost controls local client behavior:

- Temporary upper FPS cap of 60 by default, preserving lower native caps. Disabling CapFPS/the mod restores native behavior. Only the game-loop pacing call sites read the cached cap; Options and saved native settings remain unchanged.
- Optional removal of character, vehicle and corpse ground shadows. Actor drawing, maximum zoom, lighting, collision and simulation remain unchanged. MCP reports skipped shadow passes.
- Optional water/puddle shader reductions. Water/climate simulation and hazards keep running.
- A cooperating cosmetic tier reduces Levels/Zombie Types label counts and UI refresh frequency. Ability clouds retain their visibility limit. Tier zero preserves original detail.
- Less frequent nonessential hot-reload watcher polling in single-player. Native debug mode bypasses it; non-debug MP clients already bypass this watcher natively.

Sandbox > Bridge > Performance Boost controls dedicated-server maintenance: hot-reload checks run at most twice per second, keeping queued file events, and cooperating diagnostics may publish less often. Full/debug profiling retains normal diagnostic frequency. Zombie/player simulation, combat, XP, physics, server tick rate and packet processing are not throttled. These are bounded maintenance savings, not a promised whole-server speedup.

MCP `extension_status` for `pzjbridge.optimizer` reports the active budget, watcher calls and skipped polls. Base performance status includes the effective `optimizationBudget`; mod_plan reports method overlaps. Other mods can explicitly use `PerformanceHints` for nonessential work; arbitrary Lua/Java mods are not automatically rewritten or merged.

Build: `gradlew.bat :pzjbridge-performance:build :pzjbridge-performance:workshopZip`. The output under `build/distributions` is a Workshop draft ZIP. No Steam upload is performed by the build.

Install the bridge once using the client/server installers from [the public binary repository](https://github.com/rocky6777/pzJBridge-server). Then use the Workshop mod and enable it for the save/server. For local development, put this JAR in the agent's `mods` directory and install the accompanying native mod folder. Do not enable both local and subscribed copies.

Test the same warmed save, route, zoom and crowd with this mod off/on. Keep detailed profiling off for pacing comparisons and enable it briefly to investigate phases. A single good capture cannot establish compatibility or a guaranteed gain across all hardware/mod combinations.

Validation for this build: full Gradle checks; isolated B42.21 client/server native transforms; bytecode verification that pacing substitutions and the frame settings callback coexist; lower native-cap preservation; two native enable/disable cycles per side. These checks do not replace live SP/MP visual and performance comparisons.

Bridge 0.7.3 detailed profiling separates UI/world render-buffer submission, world/state updates, cosmetic shadow/rain/snow passes and client maintenance. `renderWork` reports native queued world/UI draw-command counts, capture time and skipped shadow passes. Counts require detailed mode and are not GPU timing or a count of unique visible actors.

The B42.21 FBO shadow path suppresses both addShadow overloads before allocation and skips renderMain queue submission. Native clear/endRender pool cleanup remains intact. MCP distinguishes skipped passes from skipped submission requests; requests need not correspond to visible shadows. Native fixtures verify both enable/disable restoration and exactly one optimizer frame callback and bridge render cadence callback per invocation. Version 0.1.1 only covered the legacy cell shadow renderer, which was inactive in the measured FBO session.

Version 0.2.2 adds an optional “Reduce rain/snow particles” toggle, default off. It skips native decorative rain and inherited snow drawing, preserving weather updates, fog and drawer cleanup. Debug logs, counters and MCP require an explicit debug launch; optimization policies work in normal quiet gameplay. Native fixtures verify disabled method restoration. Live wet-weather performance benefit remains unverified.

“Accelerate zombie list checks” targets repeated list searches within dense multiplayer zombie packets. Verified packet-local positive lookups preserve native membership; uncertain cases fall back. It leaves SP/server simulation and the existing object Set untouched. Debug MCP extension diagnostics expose `zombieListChecks`; enable detailed profiling for zombie/chunk subphases and bounded GC pause events. Compare the toggle off/on on the same warmed crowd before attributing an FPS gain.
